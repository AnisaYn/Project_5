import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import*

infile = open('statistics.txt')
Temperature = []
Time_step = []
i = 0
for line in infile.readlines()[1:-1]:
    words = line.split()
    Time_step.append(float(words[0]))
    Temperature.append(float(words[5]))
    


print words

Time_step = np.array(Time_step)
Temperature = np.array(Temperature)


print Temperature
print Time_step
infile.close()

fig, ax = plt.subplots()
ax.plot(Time_step,Temperature,"m-",linewidth=2)
grid(True)
title('Temperature as funtion of time steps', fontsize=20)
xlabel('Time steps', fontsize=16)
ylabel('Temperature[K]',fontsize=16)
show()