import numpy as np
import matplotlib.pyplot as plt
from matplotlib.pyplot import*

infile = open('statistics.txt')
Time = []
Kinetic_Energy = []
i = 0
for line in infile.readlines()[1:-1]:
    words = line.split()
    Kinetic_Energy.append(float(words[2]))
    Time.append(float(words[0]))
    


print words

Kinetic_Energy = np.array(Kinetic_Energy)
Time0 = np.array(Time)


print Time
print Kinetic_Energy

fig, ax = plt.subplots()
ax.plot(Time, Kinetic_Energy,"r-",linewidth=2, label='Kinetic_Energy')
infile = open('statistics.txt')
Time0 = []
Total_Energy = []
i = 0
for line in infile.readlines()[1:-1]:
    words = line.split()
    Total_Energy.append(float(words[4]))
    Time0.append(float(words[0]))
    


print words

Total_Energy = np.array(Total_Energy)
Time0 = np.array(Time)


print Time0
print Total_Energy



ax.plot(Time0, Total_Energy,"g-",linewidth=2, label='Total_Energy') 

infile = open('statistics.txt')
Time1 = []
Potential_Energy = []
i = 0
for line in infile.readlines()[1:-1]:
    words = line.split()
    Potential_Energy.append(float(words[3]))
    Time1.append(float(words[0]))
    


print words
Potential_Energy = np.array(Potential_Energy)
Time1 = np.array(Time1)


infile.close()
print Time1
print Potential_Energy


ax.plot(Time1, Potential_Energy,"b-",linewidth=2, label='Potential_Energy')

grid(True)
title('Engeries as function of Time', fontsize=20)
xlabel('Time', fontsize=16)
ylabel('Energies[Ev]',fontsize=16)

# Now add the legend with some customizations.
legend = ax.legend(loc='2', shadow=True)

# The frame is matplotlib.patches.Rectangle instance surrounding the legend.
frame = legend.get_frame()
frame.set_facecolor('0.90')

# Set the fontsize
for label in legend.get_texts():
    label.set_fontsize('large')

for label in legend.get_lines():
    label.set_linewidth(1.5)

show()